$(document).ready(function () {
    $('#rss-feed').rssfeed('http://feeds.reuters.com/reuters/oddlyEnoughNews', {
        limit: 4
    });

    if ($(".ms-cui-mrusb-selecteditem").length > 0) {

        $(".cst-sub").each(function (index, item) {
            $(item).html('    <div class=\"navbar navbar-default navbar-fixed-top\">\r\n      <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"offcanvas\" data-target=\".navmenu\"><span class=\"icon-bar\"><\/span><span class=\"icon-bar\"><\/span><span class=\"icon-bar\"><\/span><\/button>\r\n    <\/div>');
        });
        $(".navmenu-fixed-left").removeClass("offcanvas-sm");
        $(".navmenu-fixed-left").addClass("offcanvas");
        console.log(true);
    } else {
        $(".cst-sub").each(function (index, item) {
            $(item).html('        <div class=\"navbar navbar-default navbar-fixed-top hidden-md hidden-lg\">\r\n            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"offcanvas\" data-target=\".navmenu\"><span\r\n                    class=\"icon-bar\"><\/span><span class=\"icon-bar\"><\/span><span class=\"icon-bar\"><\/span><\/button>\r\n        <\/div>');
        });
        $(".navmenu-fixed-left").removeClass("offcanvas");
        $(".navmenu-fixed-left").addClass("offcanvas-sm");
        console.log(false);
    }

    var request = new XMLHttpRequest();
    request.open("GET", "http://telpac.aristotle.com/sitepages/telpac2.aspx", false);
    request.send();
    var xml = request.responseXML;
    var total = xml.getElementsByTagName("TotalAmountRaised");
    var goal = xml.getElementsByTagName("GoalAmount");
    console.log(goal);
    console.log(total);
    thermometer(goal[0].innerHTML, total[0].innerHTML, true);
});

$(function () {
    $(".rslides").responsiveSlides();
});

$(window).resize(function () {

});
